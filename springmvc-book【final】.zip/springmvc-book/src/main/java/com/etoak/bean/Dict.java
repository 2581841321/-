package com.etoak.bean;

import lombok.Data;

@Data
public class Dict {

	private Integer id;

	private String dictGroup;

	private String dictName;

	private Integer sort;

}
